Note:
1.Contents of this website only support internal portal.
===================================
Desktop version file description
===================================
login.html: The user authentication is required, pops up login.html page.
error.html: The user authentication is fail, pops up error.html page.
welcome.html: The user authentication is successfully, pops up welcome.html and session.html page.
session.html: The user authentication is successfully, pops up welcome.html and session.html page.
logout.html: The user authentication logout, pops up logout.html page.
terms_of_service.html: Terms of Service content page.
free_time.html: You can customize personal data retention page in free time feature.
===================================

===================================
Mobile version file description
===================================
login_m.html: The user authentication is required, pops up login_m.html page.
welcome_m.html: The user authentication is successfully, pops up welcome_m.html page.
session_m.html: In the welcome_m page when the user pressed OK button, pops up session_m.html page.
logout_m.html: The user authentication logout, pops up logout_m.html page.
terms_of_service_m.html: Terms of Service content page.
free_time_m.html: You can customize personal data retention page in free time feature.
===================================